import re
import numpy as np
import scipy.stats as stats
nums = []
no = '-?\d+\.?\d?'
f2 = open("samples.txt",'r')
def convert_to_int(a):
    p1 = re.compile(no).findall(str(a))
    return p1
for line in f2:
    out = convert_to_int(line)
    for i in out :
        nums.append(int(i))
import matplotlib.pyplot as plt
narr = np.array(nums)
fig = plt.gcf()
fig.set_size_inches(18.5, 10.5)
plt.hist(narr, bins=40, density=True, alpha=0.6, color='b')
mean = narr.mean()
standard_deviation = np.std(narr)
print("mean is : ",mean)
print("std is : ",standard_deviation)
x_values = np.arange(narr.min(), narr.max(), 0.1)
y_values = stats.norm(mean, standard_deviation)
plt.plot(x_values, y_values.pdf(x_values),color = "red")
plt.savefig("chart.png")
plt.show()
