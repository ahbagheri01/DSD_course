# This is a sample Python script.
import random
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


class Convertor:
    full_adder_with_half_const = "module OnebitFulladder" \
                       "(output result , output cout ,input in1,input in2,input cin)" \
                       ";\n" + "    wire s,co,co2;" + "\n" + "    HA H1(s,co , in1,in2);" + "\n" + \
                       "    HA H2(result,co2,cin,s);" + "\n" + "    or c_out(cout,co2,co);" + \
                       "\n" + "endmodule" + "\n"
    half_adder_const = "module HA(output wire result,output wire cout ,input in1,input in2);\n" + \
                       "   and out_carry(cout,in1,in2);\n" + \
                       "   xor  result_sum(result,in1,in2);\n" + \
                       "endmodule"
    def __init__(self,n):
        self.code = ""
        self.tb = ""
        self.size = n
        self.onebit_fulladder_with_half =self.full_adder_with_half_const
        self.half_adder =self.half_adder_const
        self.root_module_name = "Arraymultiplier"


        self.NbitFull_adder  = "module FullAdder\n"+\
            "#(parameter size = "+str(n)+")\n"+\
        "(output sum,output [size:1] result ,input [size-1:0] in1 ,\n"+\
        "input [size-1:0] in2);\n"+\
        "wire [size-2:0] co;\n"
        self.NbitFull_adder +="HA H0(sum,co[0] , in1[0],in2[0]);\n"
        for i in range(1,n-1):
            self.NbitFull_adder += "OnebitFulladder F"+str(i)+\
                                   "(result["+str(i)+"],co["+str(i)+"] ," \
                                                                    " in1["+str(i)+"],in2["+str(i)+"]," \
                                                                                                   "co["+str(i-1)+"]);\n"
        self.NbitFull_adder += "OnebitFulladder F" + str(n-1) + \
                               "(result[" + str(n-1) + "],result["+str(n)+"]," \
                                    " in1[" + str(n-1) + "],co[" + str(n-2) + "]," \
                                        "in2["+ str(n-1) +"]);\n"
        self.NbitFull_adder+="endmodule\n"



    def create_ands(self,level,is_it_firstlevel = False):
        if not is_it_firstlevel:
            code = "    wire [n:1] and_output"+str(level)+"s;\n"
            for i in range(1,self.size+1):
                code+="    and c"+str(level)+"_bit_"+str(i)+\
                    "(and_output"+str(level) +"s["+str(i)+"],in1["+str(i)+"],in2["+str(level)+"]);\n"
            return code
        code = "    wire [n:1] and_output" + str(level) + "s;\n"
        for i in range(1, self.size):
            code += "    and c" + str(level) + "_bit_" + str(i) + \
                    "(and_output" + str(level) + "s[" + str(i) + "],in1[" + str(i+1) + "],in2[" + str(level) + "]);\n"
        code += "    xor c" + str(level) + "_bit_" + str(self.size) + \
                    "(and_output" + str(level) + "s[" + str(self.size) + "],in2[1],in2[1]);\n"
        return code
    def create_test(self,a,b,delay):
        code =  "    in1 = "+str(a)+";\n"
        code+= "    in2  = "+str(b)+";\n"
        code+="    #"+str(delay)+"\n"
        code+="    $display(in1,\"*\",in2,\"=\",result);\n"
        code+= "    if (result ==" +str(a*b)+")\n"
        code+= "    $display(\"equal\");\n"
        code+="    else\n"
        code+="    $display(\"not equal\");\n"
        return code
    def create_tb(self):
        N = self.size
        if self.size > 14:
            N = 14
        code = "module" + " tb_" + self.root_module_name + "();\n"
        code+="    reg["+str(self.size)+":1] in1;\n"
        code+="    reg["+str(self.size)+":1] in2;\n"
        code += "    wire["+str(2*self.size)+":1] result;\n"
        code +="    Arraymultiplier  # ("+str(self.size)+")tester(result,in1,in2);\n"
        code+= "    initial\n"
        code+="    begin\n"
        for i in range(N):
            code+=self.create_test(random.randint(0,2**i),random.randint(0,2**i),4)
        code+=self.create_test(random.randint(1,2**N-1),random.randint(1,2**N-1),4)
        code+= "    end\n"
        code+="endmodule\n"
        self.tb = code
    def special_case_one(self):
        code = "module" + " " + self.root_module_name + "\n"
        code += "    (output  result ,input in1 , input in2 );\n"
        code += "    and output_1(result,in1,in2);\n"
        code += "endmodule\n\n"
        self.code = code
        code = "module" + " tb_" + self.root_module_name + "();\n"
        code += "    reg in1;\n"
        code += "    reg in2;\n"
        code += "    wire result;\n"
        code += "    Arraymultiplier  tester(result,in1,in2);\n"
        code += "    initial\n"
        code += "    begin\n"
        for i in range(3):
            code += self.create_test(random.randint(0, 1), random.randint(0, 1), 2)
        code += "    end\n"
        code += "endmodule\n"
        self.tb = code

    def create(self):
        if self.size == 1:
            self.special_case_one()
            return
        self.create_module()
        self.create_tb()

    def create_module(self):
        code = "module" + " "+ self.root_module_name+"\n"
        code+= "#(parameter n = "+str(self.size)+")"+"\n"
        code+= "    (output [1<<n:1] result ,input [n:1] in1 , input [n:1] in2 );\n"
        code += "   //level " + str(1)+"\n"
        code+= "    and output_level1(result[1],in1[1],in2[1]);\n"
        code+= self.create_ands(1,True)
        code+=self.create_ands(2)

        if self.size == 2:
            code += "   FullAdder #(n)F_sum_l" + str(2) + "(result[" + str(2) + "], result" + \
                    "[1<<n:n+1], and_output1s[n:1], and_output2s[n:1]);\n"
        else:
            code += "   wire [n:1] Fin_sum_l2;\n"
            code+= "    FullAdder #(n)F_sum_l2(result[2], Fin_sum_l2[n:1], and_output1s[n:1], and_output2s[n:1]);\n"
            for level in range(3,self.size):
                code+"    /*"+"level "+str(level)+"*/\n"
                code+="    wire [n:1] Fin_sum_l"+str(level)+";\n"
                code+= self.create_ands(level)
                code+="    FullAdder #(n)F_sum_l"+str(level)+"(result["+str(level)+"], Fin_sum_l"+str(level)+"[n:1], and_output"+str(level)+"" \
                "s[n:1], Fin_sum_l"+str(level-1)+"[n:1]);\n"
            level = self.size
            code + "    //level " + str(level) + "\n"
            code += self.create_ands(level)
            code += "    FullAdder #(n)F_sum_l" + str(level) + "(result[" + str(level) + "], result" + \
            "[1<<n:n+1], and_output" + str(level) + "" \
                                                        "s[n:1], Fin_sum_l" + str(level - 1) + "[n:1]);\n"
        code+="endmodule\n\n"

        self.code = code+"\n\n\n"+self.NbitFull_adder+"\n\n\n"+self.full_adder_with_half_const+"\n\n\n"+self.half_adder_const
    def save(self,address = "." ):
        f = open(address+"\\"+self.root_module_name+".v", "w")
        f.write(self.code)
        f.close()
        f = open(address + "\\tb_" + self.root_module_name + ".v", "w")
        f.write(self.tb)
        f.close()

if __name__ == '__main__':
    n = int(input())
    convertor = Convertor(n)
    convertor.create()
    convertor.save()

